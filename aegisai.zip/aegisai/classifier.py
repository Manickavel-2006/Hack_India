"""
AegisAI - Task Classifier
Detects the task type of an incoming query using keyword and pattern matching.
No external model required — keeps this step fast and free.
"""

import re
from typing import Tuple

# ── Keyword patterns per task type ─────────────────────────────────────────────
# Order matters: more specific patterns should come first.
# Each entry: (task_type, confidence_boost, list_of_patterns)
_PATTERNS = [
    ("coding", 0.9, [
        r"\bcode\b", r"\bprogram\b", r"\bfunction\b", r"\bscript\b",
        r"\bdebug\b", r"\brefactor\b", r"\bimplement\b", r"\bclass\b",
        r"\balgorithm\b", r"\bapi\b", r"\bsql\b", r"\bpython\b",
        r"\bjavascript\b", r"\bjava\b", r"\bc\+\+\b", r"\bhtml\b",
        r"\bcss\b", r"\bregex\b", r"\bbug\b", r"\berror\b.*\bfix\b",
        r"\bwrite.*code\b", r"\bwrite.*function\b", r"\bwrite.*class\b",
        r"\bwrite.*script\b", r"\bbuild.*app\b",
    ]),
    ("math", 0.9, [
        r"\bcalculate\b", r"\bsolve\b", r"\bequation\b", r"\bproof\b",
        r"\bderivative\b", r"\bintegral\b", r"\bmatrix\b", r"\bvector\b",
        r"\bprobability\b", r"\bstatistic\b", r"\bformula\b",
        r"\barithmetic\b", r"\balgebra\b", r"\bgeometry\b",
        r"\d+\s*[\+\-\*\/\^]\s*\d+",   # inline arithmetic like "3 + 4"
        r"\bwhat is \d",                 # "what is 42 ..."
    ]),
    ("reasoning", 0.8, [
        r"\bcompare\b", r"\banalyze\b", r"\bevaluate\b", r"\bjustify\b",
        r"\bcritique\b", r"\btradeoff\b", r"\bpros and cons\b",
        r"\bvs\b", r"\bversus\b", r"\bdifference between\b", r"\bwhy is\b", r"\bexplain why\b",
        r"\bshould i\b", r"\bwhich is better\b", r"\badvantages\b",
        r"\bdisadvantages\b", r"\bimpact of\b", r"\beffect of\b",
        r"\bdesign\b.*\bsystem\b", r"\barchitecture\b",
    ]),
    ("summarization", 0.85, [
        r"\bsummarize\b", r"\bsummary\b", r"\bbriefly\b", r"\bshorten\b",
        r"\btldr\b", r"\bkey points\b", r"\bmain points\b",
        r"\boverview\b", r"\bsynopsis\b", r"\bdistill\b",
        r"\bwhat (are|were) the (main|key|important)\b",
    ]),
    ("document", 0.9, [
        r"\bthis (document|paper|report|article|pdf|file)\b",
        r"\battached\b", r"\bthe (report|study|research)\b",
        r"\baccording to\b", r"\bbased on (the|this)\b",
        r"\bfrom (this|the) (document|text|paper)\b",
        r"\banalyze (this|the)\b",
    ]),
    ("creative", 0.8, [
        r"\bwrite (a|an|me)\b", r"\bstory\b", r"\bpoem\b", r"\bessay\b",
        r"\bbrainstorm\b", r"\bideas for\b", r"\bcreative\b",
        r"\bfiction\b", r"\bnarrative\b", r"\bdraft\b",
        r"\bcatchy\b", r"\bslogan\b", r"\bblog post\b",
    ]),
    ("factual", 0.7, [
        r"\bwhat is\b", r"\bwho is\b", r"\bwhen (did|was|is)\b",
        r"\bwhere (is|was|did)\b", r"\bdefine\b", r"\bdefinition\b",
        r"\btell me about\b", r"\bexplain\b", r"\bdescribe\b",
        r"\bhow does\b", r"\bwhat does\b",
    ]),
]


def classify_task(query: str) -> Tuple[str, float, dict]:
    """
    Classify the task type of a query.

    Returns:
        task_type (str): one of the TASK_TYPES from config.py
        confidence (float): 0.0–1.0 confidence in the classification
        scores (dict): raw match scores per task type, useful for logging
    """
    text = query.lower()
    scores: dict[str, float] = {}

    for task_type, boost, patterns in _PATTERNS:
        matched = sum(1 for p in patterns if re.search(p, text))
        if matched > 0:
            # score = fraction of patterns matched × boost, capped at 1.0
            score = min((matched / len(patterns)) * boost * 3.0, 1.0)
            scores[task_type] = round(score, 3)

    if not scores:
        return "general", 0.5, {"general": 0.5}

    best_task = max(scores, key=scores.__getitem__)
    confidence = scores[best_task]

    # If confidence is low, fall back to general
    if confidence < 0.15:
        return "general", confidence, scores

    return best_task, round(confidence, 3), scores


def estimate_complexity(query: str, has_document: bool = False) -> Tuple[float, list]:
    """
    Score query complexity 0.0–1.0 using multiple signals.
    Returns (score, list_of_reasons).
    """
    score = 0.0
    reasons = []

    # Signal 1: length
    word_count = len(query.split())
    if word_count > 40:
        score += 0.25
        reasons.append(f"long query ({word_count} words)")
    elif word_count > 20:
        score += 0.12
        reasons.append(f"medium query ({word_count} words)")

    # Signal 2: reasoning keywords
    reasoning_kw = [
        "compare", "analyze", "justify", "predict", "explain why",
        "evaluate", "recommend", "design", "critique", "tradeoffs",
        "pros and cons", "differences between",
    ]
    found_kw = [kw for kw in reasoning_kw if kw in query.lower()]
    if found_kw:
        score += 0.35
        reasons.append(f"reasoning keywords: {found_kw}")

    # Signal 3: sub-task bundling
    sub_tasks = query.lower().count(" and ") + query.count(",")
    if sub_tasks >= 3:
        score += 0.20
        reasons.append(f"multiple sub-tasks ({sub_tasks} signals)")
    elif sub_tasks >= 1:
        score += 0.08
        reasons.append("secondary clause detected")

    # Signal 4: document attached
    if has_document:
        score += 0.20
        reasons.append("document attached — requires contextual analysis")

    # Signal 5: multi-step markers
    multi_step = re.findall(r"\b(first|then|finally|step \d|next)\b", query.lower())
    if len(multi_step) >= 2:
        score += 0.10
        reasons.append(f"multi-step structure ({len(multi_step)} markers)")

    if not reasons:
        reasons.append("short, direct query")

    return round(min(score, 1.0), 2), reasons