"""
AegisAI - Token Economy Engine v2
Improvements over v1:
  - Pre-flight token prediction before sending to model
  - Adaptive compression aggressiveness based on document size
  - Better paragraph reconstruction for PDFs
  - Returns structured compression report
"""

import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

import re
import time

import numpy as np
from sentence_transformers import SentenceTransformer
from pypdf import PdfReader

# ── Embedding model (lazy-loaded on first use) ────────────────────────────────
_embedder = None

def _get_embedder():
    """Lazy initialization of embedding model (load on first use, cache forever)."""
    global _embedder
    if _embedder is None:
        try:
            _embedder = SentenceTransformer("all-MiniLM-L6-v2")
        except Exception as e:
            # Graceful degradation: warn but don't crash during startup
            print(f"⚠️  Warning: Could not load embedding model: {e}")
            print("   Some compression features may be unavailable.")
            _embedder = None
    return _embedder

# ── Tuned thresholds (calibrated against real all-MiniLM-L6-v2 output) ────────
DEDUP_SIMILARITY_THRESHOLD = 0.80   # cosine sim above this = near-duplicate
SUMMARIZE_BOTTOM_FRACTION  = 0.35   # compress the least-relevant X% of chunks


# ── Utility ───────────────────────────────────────────────────────────────────
def estimate_tokens(text: str) -> int:
    """~4 chars per token — standard approximation for English text."""
    return max(1, len(text) // 4)


def predict_token_usage(query: str, context: str = "") -> dict:
    """
    Pre-flight token prediction BEFORE making the API call.
    Returns input/output estimates and estimated prompt structure.
    """
    input_tokens = estimate_tokens(query) + estimate_tokens(context)
    # Heuristic: output is typically 1.5–3× the query length for analytical tasks
    estimated_output = max(100, estimate_tokens(query) * 2)
    return {
        "predicted_input_tokens":  input_tokens,
        "predicted_output_tokens": estimated_output,
        "predicted_total_tokens":  input_tokens + estimated_output,
    }


def _cosine_similarity(a, b) -> float:
    norm_a = np.linalg.norm(a)
    norm_b = np.linalg.norm(b)
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return float(np.dot(a, b) / (norm_a * norm_b))


# ── Extraction ─────────────────────────────────────────────────────────────────
def extract_text(file_path: str) -> str:
    """Extract raw text from .txt, .md, or .pdf."""
    ext = os.path.splitext(file_path)[1].lower()
    if ext in (".txt", ".md"):
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
    elif ext == ".pdf":
        reader = PdfReader(file_path)
        pages = [page.extract_text() or "" for page in reader.pages]
        raw = "\n".join(pages)
        return _fix_pdf_paragraphs(raw)
    else:
        raise ValueError(f"Unsupported file type: {ext}. Supported: .txt, .md, .pdf")


def _fix_pdf_paragraphs(raw_text: str) -> str:
    """
    pypdf loses paragraph breaks — reconstruct them using a short-line heuristic.
    Lines with ≤6 words and no ending punctuation are treated as section headers.
    """
    lines = [ln.strip() for ln in raw_text.split("\n") if ln.strip()]
    paragraphs, current = [], []
    for line in lines:
        wc = len(line.split())
        is_header = wc <= 6 and not line.endswith((".", ",", ";", ":"))
        if is_header and current:
            paragraphs.append(" ".join(current))
            current = []
            paragraphs.append(line)
        elif is_header:
            paragraphs.append(line)
        else:
            current.append(line)
    if current:
        paragraphs.append(" ".join(current))
    return "\n\n".join(paragraphs)


# ── Chunking ──────────────────────────────────────────────────────────────────
def chunk_text(text: str, min_chunk_words: int = 20) -> list:
    """Split text into paragraph-level chunks; merge short fragments."""
    raw = re.split(r"\n\s*\n", text.strip())
    raw = [p.strip().replace("\n", " ") for p in raw if p.strip()]
    chunks, buffer = [], ""
    for para in raw:
        buffer = (buffer + " " + para).strip() if buffer else para
        if len(buffer.split()) >= min_chunk_words:
            chunks.append(buffer)
            buffer = ""
    if buffer:
        if chunks:
            chunks[-1] += " " + buffer
        else:
            chunks.append(buffer)
    return chunks


# ── Semantic deduplication ────────────────────────────────────────────────────
def deduplicate_chunks(chunks: list) -> tuple:
    """Remove near-duplicate chunks. Returns (deduped, num_removed)."""
    if len(chunks) <= 1:
        return chunks, 0
    embedder = _get_embedder()
    if embedder is None:
        # If embedder unavailable, return all chunks (no deduplication)
        return chunks, 0
    embeddings = embedder.encode(chunks)
    keep = [True] * len(chunks)
    for i in range(len(chunks)):
        if not keep[i]:
            continue
        for j in range(i + 1, len(chunks)):
            if not keep[j]:
                continue
            if _cosine_similarity(embeddings[i], embeddings[j]) >= DEDUP_SIMILARITY_THRESHOLD:
                keep[j] = False
    deduped = [c for c, k in zip(chunks, keep) if k]
    return deduped, len(chunks) - len(deduped)


# ── Relevance ranking ─────────────────────────────────────────────────────────
def rank_by_relevance(chunks: list, query: str) -> list:
    """Sort chunks most-relevant-first against the query."""
    if not chunks:
        return []
    embedder = _get_embedder()
    if embedder is None:
        # If embedder unavailable, return chunks in original order
        return [{"text": c, "relevance": 0.0} for c in chunks]
    q_emb = embedder.encode([query])[0]
    c_embs = embedder.encode(chunks)
    scored = [{"text": c, "relevance": round(_cosine_similarity(q_emb, e), 4)}
              for c, e in zip(chunks, c_embs)]
    scored.sort(key=lambda x: x["relevance"], reverse=True)
    return scored


# ── Summarization (uses AMRE's small model) ───────────────────────────────────
def _summarize_chunk(chunk: str, groq_client, small_model_id: str) -> str:
    """Compress a low-priority chunk to 1-2 sentences."""
    resp = groq_client.chat.completions.create(
        model=small_model_id,
        messages=[{"role": "user", "content":
            f"Summarize in 1-2 concise sentences, preserving key facts:\n\n{chunk}"}],
    )
    return resp.choices[0].message.content.strip()


# ── Full pipeline ─────────────────────────────────────────────────────────────
def compress_document(
    file_path: str,
    query: str,
    groq_client=None,
    small_model_id: str = "llama-3.1-8b-instant",
    summarize_low_relevance: bool = True,
) -> dict:
    """
    Full Token Economy pipeline:
      extract → chunk → dedup → rank → summarize low-relevance → measure

    Returns a structured compression report including token prediction.
    """
    start = time.perf_counter()

    raw_text = extract_text(file_path)
    original_tokens = estimate_tokens(raw_text)

    chunks = chunk_text(raw_text)
    chunks_before = len(chunks)

    deduped, num_removed = deduplicate_chunks(chunks)
    ranked = rank_by_relevance(deduped, query)

    # Adaptive aggressiveness: compress more when document is large
    # For large docs (>500 tokens/chunk avg), be more aggressive
    avg_chunk_tokens = original_tokens / max(chunks_before, 1)
    bottom_fraction = SUMMARIZE_BOTTOM_FRACTION
    if avg_chunk_tokens > 200:
        bottom_fraction = min(0.50, SUMMARIZE_BOTTOM_FRACTION + 0.10)

    cutoff = max(1, int(len(ranked) * (1 - bottom_fraction)))
    final_chunks = []
    num_summarized = 0

    for idx, item in enumerate(ranked):
        if summarize_low_relevance and groq_client and idx >= cutoff:
            summary = _summarize_chunk(item["text"], groq_client, small_model_id)
            final_chunks.append(summary)
            num_summarized += 1
        else:
            final_chunks.append(item["text"])

    optimized_context = "\n\n".join(final_chunks)
    optimized_tokens = estimate_tokens(optimized_context)
    elapsed = round(time.perf_counter() - start, 3)

    reduction_pct = round(
        (1 - optimized_tokens / original_tokens) * 100, 1
    ) if original_tokens > 0 else 0.0

    # Pre-flight prediction for the full query+context call
    prediction = predict_token_usage(query, optimized_context)

    return {
        "original_tokens":            original_tokens,
        "optimized_tokens":           optimized_tokens,
        "token_reduction_percent":    reduction_pct,
        "chunks_before_dedup":        chunks_before,
        "chunks_removed_as_duplicates": num_removed,
        "chunks_after_dedup":         len(deduped),
        "chunks_summarized":          num_summarized,
        "processing_time_seconds":    elapsed,
        "token_prediction":           prediction,
        "optimized_context":          optimized_context,
        "optimized_context_preview":  optimized_context[:500],
    }