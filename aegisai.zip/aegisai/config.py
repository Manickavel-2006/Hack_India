"""
AegisAI - Model Registry & Configuration
Defines all available models, their capabilities, pricing, and latency profiles.
This is the single source of truth for model selection decisions.
"""

from dataclasses import dataclass, field
from typing import List

# ── Task types AegisAI can classify ───────────────────────────────────────────
TASK_TYPES = [
    "coding",           # code generation, debugging, review
    "math",             # arithmetic, algebra, proofs
    "reasoning",        # multi-step logic, analysis, compare/evaluate
    "summarization",    # distill long content into shorter form
    "factual",          # simple factual lookup, definitions
    "document",         # analyze/extract from an attached document
    "creative",         # writing, brainstorming, storytelling
    "general",          # catch-all
]


@dataclass
class ModelProfile:
    """Complete profile for one model in the registry."""
    model_id: str                    # exact Groq API model string
    display_name: str                # human-readable label
    size_b: float                    # parameter count in billions
    context_window: int              # max tokens

    # Cost in USD per million tokens (approximate Groq pricing)
    cost_per_m_input: float
    cost_per_m_output: float

    # Relative capability scores 0-10 per task type
    # Higher = better at this task
    task_scores: dict = field(default_factory=dict)

    # Latency profile (seconds) — updated dynamically from routing history
    avg_latency_seconds: float = 1.0

    # Whether this model is currently available (can be toggled if API key fails)
    available: bool = True


# ── Model registry ─────────────────────────────────────────────────────────────
# Ordered roughly small → large. Scores are based on documented benchmarks
# and community evaluations as of mid-2025.
MODEL_REGISTRY: List[ModelProfile] = [
    ModelProfile(
        model_id="llama-3.1-8b-instant",
        display_name="Llama 3.1 8B (Fast)",
        size_b=8,
        context_window=131072,
        cost_per_m_input=0.05,
        cost_per_m_output=0.08,
        task_scores={
            "factual":       9,
            "general":       7,
            "summarization": 6,
            "creative":      6,
            "coding":        5,
            "math":          4,
            "reasoning":     4,
            "document":      5,
        },
        avg_latency_seconds=0.5,
    ),
    ModelProfile(
        model_id="meta-llama/llama-4-scout-17b-16e-instruct",
        display_name="Llama 4 Scout 17B",
        size_b=17,
        context_window=131072,
        cost_per_m_input=0.11,
        cost_per_m_output=0.34,
        task_scores={
            "factual":       8,
            "general":       8,
            "summarization": 8,
            "creative":      7,
            "coding":        7,
            "math":          6,
            "reasoning":     7,
            "document":      8,
        },
        avg_latency_seconds=1.2,
    ),
    ModelProfile(
        model_id="openai/gpt-oss-20b",
        display_name="GPT-OSS 20B",
        size_b=20,
        context_window=131072,
        cost_per_m_input=0.20,
        cost_per_m_output=0.20,
        task_scores={
            "factual":       8,
            "general":       8,
            "summarization": 9,
            "creative":      8,
            "coding":        7,
            "math":          6,
            "reasoning":     7,
            "document":      8,
        },
        avg_latency_seconds=1.8,
    ),
    ModelProfile(
        model_id="qwen/qwen3-32b",
        display_name="Qwen3 32B",
        size_b=32,
        context_window=131072,
        cost_per_m_input=0.29,
        cost_per_m_output=0.39,
        task_scores={
            "factual":       8,
            "general":       8,
            "summarization": 8,
            "creative":      7,
            "coding":        9,   # Qwen3 excels at code
            "math":          9,   # and math
            "reasoning":     8,
            "document":      7,
        },
        avg_latency_seconds=2.0,
    ),
    ModelProfile(
        model_id="llama-3.3-70b-versatile",
        display_name="Llama 3.3 70B (Versatile)",
        size_b=70,
        context_window=131072,
        cost_per_m_input=0.59,
        cost_per_m_output=0.79,
        task_scores={
            "factual":       9,
            "general":       9,
            "summarization": 9,
            "creative":      9,
            "coding":        8,
            "math":          8,
            "reasoning":     10,  # strongest reasoning in registry
            "document":      9,
        },
        avg_latency_seconds=2.5,
    ),
]

# Quick lookup by model_id
MODEL_BY_ID = {m.model_id: m for m in MODEL_REGISTRY}

# ── Routing weights ─────────────────────────────────────────────────────────────
# These control how the AMRE scoring function balances competing factors.
# All weights should sum to 1.0.
ROUTING_WEIGHTS = {
    "task_score":   0.40,   # how well the model fits the detected task type
    "complexity":   0.25,   # penalize cheap models for complex queries
    "cost":         0.20,   # prefer cheaper models when quality is comparable
    "latency":      0.15,   # prefer faster models when latency matters
}

# ── Cost thresholds ─────────────────────────────────────────────────────────────
# Complexity score boundaries for routing guidance
COMPLEXITY_THRESHOLDS = {
    "simple":   0.30,   # below this → small/cheap models preferred
    "moderate": 0.60,   # between simple and this → mid-tier
    "complex":  1.00,   # above moderate → large models preferred
}

# ── Fallback chain ──────────────────────────────────────────────────────────────
# If the primary model fails, try these in order
FALLBACK_ORDER = [
    "llama-3.3-70b-versatile",
    "qwen/qwen3-32b",
    "openai/gpt-oss-20b",
    "meta-llama/llama-4-scout-17b-16e-instruct",
    "llama-3.1-8b-instant",
]

# ── Timeouts ────────────────────────────────────────────────────────────────────
REQUEST_TIMEOUT_SECONDS = 30   # give up on a model after this many seconds
MAX_FALLBACK_ATTEMPTS = 2      # try at most this many fallback models