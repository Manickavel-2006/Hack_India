"""
AegisAI - FastAPI Application
Exposes the full AegisAI pipeline as REST endpoints.

Endpoints:
  GET  /              — API info
  GET  /dashboard     — Serve the observability dashboard
  POST /query         — Plain text query (AMRE routing only)
  POST /query-with-document — Full pipeline (Token Economy + AMRE)
  GET  /logs/routing  — All routing log entries (for dashboard)
  GET  /logs/history  — Model performance history (for dashboard)
"""

import os
import shutil

from fastapi import FastAPI, UploadFile, Form
from fastapi.responses import JSONResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from amre import route_query, client, initialize_classifier_at_startup, get_classifier_init_time
from token_economy import compress_document
from logger import log_routing_decision, get_all_routing_logs, get_routing_history

# ── App setup ──────────────────────────────────────────────────────────────────
app = FastAPI(title="AegisAI", version="2.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)


# ── Startup initialization ─────────────────────────────────────────────────────
@app.on_event("startup")
async def startup_event():
    """
    Pre-load the zero-shot classifier during application startup.
    This ensures the model is cached before the first request arrives,
    so per-request timing metrics only measure actual inference time.
    """
    init_time_ms = initialize_classifier_at_startup()
    print(f"✓ AegisAI startup: Zero-Shot Classifier initialized in {init_time_ms:.2f}ms")


# ── Dashboard ─────────────────────────────────────────────────────────────────
@app.get("/dashboard")
def serve_dashboard():
    """Serve the observability dashboard HTML file."""
    return FileResponse("dashboard.html")


# ── Root ──────────────────────────────────────────────────────────────────────
@app.get("/")
def root():
    init_time = get_classifier_init_time()
    return {
        "service": "AegisAI v2",
        "description": "Adaptive Multi-Modal Reasoning Engine for Cost-Efficient AI",
        "startup_status": {
            "classifier_initialized": init_time is not None,
            "classifier_init_time_ms": round(init_time, 2) if init_time else None,
        },
        "endpoints": {
            "POST /query":                "Plain text query → AMRE routing",
            "POST /query-with-document":  "Query + file → Token Economy + AMRE",
            "GET  /logs/routing":         "Full routing log (dashboard data)",
            "GET  /logs/history":         "Per-model performance history",
            "GET  /dashboard":            "Observability dashboard UI",
        }
    }


# ── Plain text query ──────────────────────────────────────────────────────────
class QueryRequest(BaseModel):
    query: str


@app.post("/query")
def handle_query(request: QueryRequest):
    """
    Route a plain text query through AMRE.
    Returns full routing decision: task type, complexity, model ranking, cost, answer.
    """
    result = route_query(
        query=request.query,
        has_document=False,
        source="live_api",
    )
    result["original_query"] = request.query
    result["token_economy"] = None

    log_routing_decision(
        query=result["query"],
        original_query=result["original_query"],
        task_type=result["task_type"],
        task_confidence=result["task_confidence"],
        complexity_score=result["complexity_score"],
        complexity_reasons=result["complexity_reasons"],
        model_id=result["model_id"],
        model_display_name=result["model_display_name"],
        routing_score=result["routing_score"],
        all_model_scores=result["all_model_scores"],
        estimated_cost_usd=result["estimated_cost_usd"],
        actual_cost_usd=result["actual_cost_usd"],
        input_tokens=result["input_tokens"],
        output_tokens=result["output_tokens"],
        latency_seconds=result["latency_seconds"],
        answer=result["answer"],
        token_prediction=None,
        token_economy=None,
        compression_ratio=None,
        fallback_used=result["fallback_used"],
        fallback_from=result["fallback_from"],
        fallback_reason=result["fallback_reason"],
        source=result["source"],
        classifier=result.get("classifier"),
        execution_timing=result.get("execution_timing"),
        routing_explanation=result.get("routing_explanation"),
        complexity_description=result.get("complexity_description"),
        cost_saved=result.get("cost_saved"),
    )
    return _format_response(result)


# ── Query with document ───────────────────────────────────────────────────────
@app.post("/query-with-document")
async def handle_query_with_document(
    query: str = Form(...),
    file: UploadFile = None,
):
    """
    Full pipeline: Token Economy compression → AMRE routing → generation.
    Accepts a .txt, .md, or .pdf file alongside the query.
    """
    if file is None:
        return JSONResponse(status_code=400, content={
            "error": "No file uploaded. Use /query for plain text queries."
        })

    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in (".txt", ".md", ".pdf"):
        return JSONResponse(status_code=400, content={
            "error": f"Unsupported file type '{ext}'. Supported: .txt, .md, .pdf"
        })

    saved_path = os.path.join(UPLOAD_DIR, file.filename)
    with open(saved_path, "wb") as f:
        shutil.copyfileobj(file.file, f)

    try:
        # Step 1: Token Economy
        compression = compress_document(
            file_path=saved_path,
            query=query,
            groq_client=client,
            small_model_id="llama-3.1-8b-instant",
        )
    finally:
        os.remove(saved_path)

    # Step 2: Build augmented query with compressed context
    augmented_query = (
        f"{query}\n\n--- Compressed document context ---\n"
        f"{compression['optimized_context']}"
    )

    # Step 3: AMRE routing + generation
    result = route_query(
        query=augmented_query,
        has_document=True,
        source="live_api_with_document",
    )

    # Attach token economy data to the log record
    token_economy = {
        "original_tokens":              compression["original_tokens"],
        "optimized_tokens":             compression["optimized_tokens"],
        "token_reduction_percent":      compression["token_reduction_percent"],
        "compression_ratio":            round(
            compression["optimized_tokens"] / compression["original_tokens"], 4
        ) if compression["original_tokens"] else None,
        "chunks_removed_as_duplicates": compression["chunks_removed_as_duplicates"],
        "chunks_summarized":            compression["chunks_summarized"],
        "token_prediction":             compression["token_prediction"],
    }
    result["original_query"] = query
    result["token_economy"] = token_economy

    log_routing_decision(
        query=result["query"],
        original_query=result["original_query"],
        task_type=result["task_type"],
        task_confidence=result["task_confidence"],
        complexity_score=result["complexity_score"],
        complexity_reasons=result["complexity_reasons"],
        model_id=result["model_id"],
        model_display_name=result["model_display_name"],
        routing_score=result["routing_score"],
        all_model_scores=result["all_model_scores"],
        estimated_cost_usd=result["estimated_cost_usd"],
        actual_cost_usd=result["actual_cost_usd"],
        input_tokens=result["input_tokens"],
        output_tokens=result["output_tokens"],
        latency_seconds=result["latency_seconds"],
        answer=result["answer"],
        token_prediction=token_economy["token_prediction"],
        token_economy=token_economy,
        compression_ratio=token_economy["compression_ratio"],
        fallback_used=result["fallback_used"],
        fallback_from=result["fallback_from"],
        fallback_reason=result["fallback_reason"],
        source=result["source"],
        classifier=result.get("classifier"),
        execution_timing=result.get("execution_timing"),
        routing_explanation=result.get("routing_explanation"),
        complexity_description=result.get("complexity_description"),
        cost_saved=result.get("cost_saved"),
    )

    return _format_response(result, compression=compression)


# ── Log endpoints ─────────────────────────────────────────────────────────────
@app.get("/logs/routing")
def get_routing_logs():
    """Return all routing log entries for the dashboard."""
    return get_all_routing_logs()


@app.get("/logs/history")
def get_history():
    """Return per-model performance history."""
    return list(get_routing_history().values())


# ── Response formatter ────────────────────────────────────────────────────────
def _format_response(result: dict, compression: dict = None) -> dict:
    """Shape the API response consistently for all endpoints."""
    response = {
        "query":           result.get("original_query") or result["query"],
        "task_type":       result["task_type"],
        "task_confidence": result["task_confidence"],
        "complexity_score":   result["complexity_score"],
        "complexity_reasons": result["complexity_reasons"],
        "routing": {
            "model_id":          result["model_id"],
            "model_name":        result["model_display_name"],
            "routing_score":     result["routing_score"],
            "all_model_scores":  result["all_model_scores"],
            "fallback_used":     result["fallback_used"],
            "fallback_from":     result["fallback_from"],
            "fallback_reason":   result["fallback_reason"],
        },
        "performance": {
            "latency_seconds":    result["latency_seconds"],
            "input_tokens":       result["input_tokens"],
            "output_tokens":      result["output_tokens"],
            "estimated_cost_usd": result["estimated_cost_usd"],
            "actual_cost_usd":    result["actual_cost_usd"],
        },
        "answer": result["answer"],
    }

    if compression:
        response["token_economy"] = {
            "original_tokens_estimate": compression["original_tokens"],
            "optimized_tokens_estimate": compression["optimized_tokens"],
            "token_reduction_percent": compression["token_reduction_percent"],
            "chunks_removed_as_duplicates": compression["chunks_removed_as_duplicates"],
            "chunks_summarized": compression["chunks_summarized"],
            "token_prediction": compression["token_prediction"],
        }

    return response