"""
AegisAI - AMRE (Adaptive Multi-Modal Reasoning Engine) v2
Multi-factor model scoring and ranking engine.

Flow:
  1. Classify task type (coding / math / reasoning / summarization / etc.)
  2. Estimate query complexity
  3. Score ALL registered models across 4 weighted dimensions
  4. Rank models → pick the highest scorer
  5. Call the model; if it fails/times out, fall back automatically
  6. Log the full decision trace
"""

import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

import time
from typing import Optional

from groq import Groq

from config import (
    MODEL_REGISTRY, MODEL_BY_ID, ROUTING_WEIGHTS,
    COMPLEXITY_THRESHOLDS, FALLBACK_ORDER,
    REQUEST_TIMEOUT_SECONDS, MAX_FALLBACK_ATTEMPTS,
)
from classifier import classify_task, estimate_complexity
from logger import get_routing_history, calculate_cost_usd, estimate_cost_usd

# ── Groq client ───────────────────────────────────────────────────────────────
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "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")
client = Groq(api_key=GROQ_API_KEY)


# ── Model scoring ──────────────────────────────────────────────────────────────
def _score_model(
    model,
    task_type: str,
    complexity: float,
    estimated_input_tokens: int,
    history: dict,
) -> float:
    """
    Score a single model for the current query. Returns 0.0–1.0.
    Higher = better fit for this specific query.

    Four weighted dimensions (weights defined in config.ROUTING_WEIGHTS):
      1. task_score   — how well this model handles the detected task type
      2. complexity   — does the model's capability match the query complexity?
      3. cost         — cheaper models score higher (inverted cost)
      4. latency      — faster models score higher (inverted latency)
    """
    w = ROUTING_WEIGHTS

    # 1. Task score (0-10 normalised to 0-1)
    raw_task = model.task_scores.get(task_type, model.task_scores.get("general", 5))
    task_dim = raw_task / 10.0

    # 2. Complexity match
    # Simple queries should prefer cheap/fast models → penalty for overkill.
    # Complex queries should prefer large models → penalty for underpowered.
    if complexity < COMPLEXITY_THRESHOLDS["simple"]:
        # Simple query: large models are wasteful — penalise by size
        complexity_dim = 1.0 - (model.size_b / 100.0)
    elif complexity < COMPLEXITY_THRESHOLDS["moderate"]:
        # Moderate: reward mid-size models
        ideal_size = 20.0
        complexity_dim = 1.0 - abs(model.size_b - ideal_size) / 70.0
    else:
        # Complex: reward large models
        complexity_dim = model.size_b / 100.0

    complexity_dim = max(0.0, min(1.0, complexity_dim))

    # 3. Cost (lower cost → higher score)
    # Normalise against most expensive model in registry
    max_cost = max(m.cost_per_m_input + m.cost_per_m_output for m in MODEL_REGISTRY)
    model_cost = model.cost_per_m_input + model.cost_per_m_output
    cost_dim = 1.0 - (model_cost / max_cost)

    # Adjust cost weight based on complexity: complex queries prioritise quality over cost
    cost_weight = w["cost"] * (1.0 - complexity * 0.5)

    # 4. Latency (lower latency → higher score)
    # Use historical avg if available, else profile default
    hist = history.get(model.model_id, {})
    actual_latency = hist.get("avg_latency", model.avg_latency_seconds)
    max_latency = max(m.avg_latency_seconds for m in MODEL_REGISTRY)
    latency_dim = 1.0 - (actual_latency / max_latency)

    # Weighted sum
    score = (
        w["task_score"]  * task_dim +
        w["complexity"]  * complexity_dim +
        cost_weight      * cost_dim +
        w["latency"]     * latency_dim
    )

    return round(min(max(score, 0.0), 1.0), 4)


def rank_models(
    task_type: str,
    complexity: float,
    estimated_input_tokens: int,
) -> list:
    """
    Score and rank ALL available models for the current query.
    Returns a list of dicts sorted best-first.
    """
    history = get_routing_history()
    ranked = []
    for model in MODEL_REGISTRY:
        if not model.available:
            continue
        score = _score_model(model, task_type, complexity, estimated_input_tokens, history)
        est_cost = estimate_cost_usd(model, estimated_input_tokens)
        ranked.append({
            "model_id":      model.model_id,
            "display_name":  model.display_name,
            "score":         score,
            "estimated_cost_usd": est_cost,
            "avg_latency":   history.get(model.model_id, {}).get("avg_latency", model.avg_latency_seconds),
            "task_score":    model.task_scores.get(task_type, model.task_scores.get("general", 5)),
        })

    ranked.sort(key=lambda x: x["score"], reverse=True)
    for i, r in enumerate(ranked):
        r["rank"] = i + 1

    return ranked


# ── Model call with fallback ───────────────────────────────────────────────────
def _call_model(model_id: str, query: str) -> tuple:
    """
    Call a single model. Returns (answer, usage, latency_seconds).
    Raises on timeout or API error.
    """
    start = time.perf_counter()
    response = client.chat.completions.create(
        model=model_id,
        messages=[{"role": "user", "content": query}],
        timeout=REQUEST_TIMEOUT_SECONDS,
    )
    latency = round(time.perf_counter() - start, 3)
    answer = response.choices[0].message.content
    usage = response.usage
    return answer, usage, latency


# ── Public routing function ────────────────────────────────────────────────────
def route_query(
    query: str,
    has_document: bool = False,
    source: str = "live_api",
) -> dict:
    """
    Full AMRE routing pipeline.

    1. Classify task type
    2. Estimate complexity
    3. Rank all models
    4. Call best model (with automatic fallback on failure)
    5. Log everything
    6. Return complete decision record
    """
    # ── Step 1: Classify ──────────────────────────────────────────────────────
    task_type, task_confidence, task_scores = classify_task(query)

    # ── Step 2: Complexity ────────────────────────────────────────────────────
    complexity, complexity_reasons = estimate_complexity(query, has_document)

    # ── Step 3: Rank ──────────────────────────────────────────────────────────
    estimated_input_tokens = max(1, len(query) // 4)
    ranked = rank_models(task_type, complexity, estimated_input_tokens)

    if not ranked:
        raise RuntimeError("No available models in registry.")

    # ── Step 4: Call with fallback ────────────────────────────────────────────
    answer = ""
    usage = None
    latency = 0.0
    chosen_model_id = ranked[0]["model_id"]
    fallback_used = False
    fallback_from: Optional[str] = None
    fallback_reason: Optional[str] = None

    primary = ranked[0]["model_id"]
    attempts = 0
    tried = set()

    # Build fallback order: primary first, then registry fallback chain
    fallback_chain = [primary] + [
        m for m in FALLBACK_ORDER
        if m != primary and m in MODEL_BY_ID
    ]

    for model_id in fallback_chain:
        if model_id in tried:
            continue
        if attempts > MAX_FALLBACK_ATTEMPTS:
            break
        tried.add(model_id)

        try:
            answer, usage, latency = _call_model(model_id, query)
            chosen_model_id = model_id

            if attempts > 0:
                fallback_used = True
                fallback_from = primary
                fallback_reason = f"Fell back from {primary} after {attempts} attempt(s)"

            break

        except Exception as e:
            attempts += 1
            if attempts == 1:
                fallback_from = model_id
                fallback_reason = str(e)[:120]
            # Mark model as temporarily unavailable in memory (not persisted)
            if model_id in MODEL_BY_ID:
                MODEL_BY_ID[model_id].available = False
            continue

    if not answer:
        raise RuntimeError("All models failed. Check API key and network.")

    # ── Step 5: Calculate actual cost ─────────────────────────────────────────
    chosen_profile = MODEL_BY_ID[chosen_model_id]
    input_tokens  = usage.prompt_tokens     if usage else estimated_input_tokens
    output_tokens = usage.completion_tokens if usage else 300
    actual_cost   = calculate_cost_usd(chosen_profile, input_tokens, output_tokens)
    est_cost      = ranked[0]["estimated_cost_usd"]

    return {
        "timestamp": None,
        "source": source,
        "query": query,
        "task_type": task_type,
        "task_confidence": task_confidence,
        "complexity_score": complexity,
        "complexity_reasons": complexity_reasons,
        "model_id": chosen_model_id,
        "model_display_name": chosen_profile.display_name,
        "routing_score": next((r["score"] for r in ranked if r["model_id"] == chosen_model_id), 0.0),
        "all_model_scores": ranked,
        "estimated_cost_usd": est_cost,
        "actual_cost_usd": actual_cost,
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "total_tokens": input_tokens + output_tokens,
        "latency_seconds": latency,
        "fallback_used": fallback_used,
        "fallback_from": fallback_from,
        "fallback_reason": fallback_reason,
        "answer_preview": answer[:300] if answer else "",
        "answer": answer,
    }


