"""
AegisAI - AMRE (Adaptive Multi-Modal Reasoning Engine) v2
Multi-factor model scoring and ranking engine.

Routing philosophy:
  Always select the SMALLEST model that can answer the query with acceptable
  quality. Only escalate to a larger model when:
    - complexity justifies it
    - the task requires stronger reasoning / coding capability
    - the smaller model's expected quality is insufficient

Flow:
  1. Classify task type    → ZeroShotClassifier (DeBERTa NLI)
  2. Estimate complexity   → rule-based (from classifier.py)
  3. Select candidate pool → task-specific, complexity-aware
  4. Score & rank pool     → dynamic per-complexity weights
  5. Call best model       → automatic fallback chain on failure
  6. Log + return          → full decision trace with timing
"""

import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

import time
from typing import Optional

from groq import Groq

from config import (
    MODEL_REGISTRY, MODEL_BY_ID,
    COMPLEXITY_THRESHOLDS,
    REQUEST_TIMEOUT_SECONDS, MAX_FALLBACK_ATTEMPTS,
)
from classifier import estimate_complexity
from zero_shot_classifier import ZeroShotClassifier
from logger import get_routing_history, calculate_cost_usd, estimate_cost_usd

# ── Groq client ───────────────────────────────────────────────────────────────
GROQ_API_KEY = os.getenv(
    "GROQ_API_KEY",
    "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",
)
client = Groq(api_key=GROQ_API_KEY)

# ── Zero-shot classifier singleton ────────────────────────────────────────────
# Instantiated once at module load so the DeBERTa model is in memory
# before the first request arrives. Every call to route_query() reuses it.
_zero_shot_classifier: Optional[ZeroShotClassifier] = None
_classifier_init_time_ms: Optional[float] = None


def _get_classifier() -> ZeroShotClassifier:
    """Return the cached classifier, creating it on first call."""
    global _zero_shot_classifier
    if _zero_shot_classifier is None:
        _zero_shot_classifier = ZeroShotClassifier()
    return _zero_shot_classifier


def initialize_classifier_at_startup() -> float:
    """
    Pre-load the zero-shot classifier during FastAPI startup.
    Call this from main.py lifespan so the first real request
    does not pay the model-load cost.

    Returns:
        Initialization time in milliseconds.
    """
    global _classifier_init_time_ms
    t0 = time.perf_counter()
    _get_classifier()
    _classifier_init_time_ms = (time.perf_counter() - t0) * 1000
    return _classifier_init_time_ms


def get_classifier_init_time() -> Optional[float]:
    """Return startup model-load time (ms), or None if not yet initialized."""
    return _classifier_init_time_ms


# ── Complexity helpers ────────────────────────────────────────────────────────

def _complexity_tier(complexity: float) -> str:
    """Return 'simple' | 'moderate' | 'complex'."""
    if complexity < COMPLEXITY_THRESHOLDS["simple"]:
        return "simple"
    if complexity < COMPLEXITY_THRESHOLDS["moderate"]:
        return "moderate"
    return "complex"


def _complexity_description(complexity: float) -> str:
    """e.g. '23% - Simple'"""
    tier = _complexity_tier(complexity).capitalize()
    return f"{int(complexity * 100)}% - {tier}"


def _estimate_input_tokens(query: str) -> int:
    return max(1, len(query) // 4)


# ── Candidate pool ────────────────────────────────────────────────────────────
# All five models always appear so the dashboard shows a full ranking.
# Order reflects preference for each task type, but the scoring function
# picks the winner — order here only breaks exact score ties.

_TASK_CANDIDATE_POOLS: dict[str, list[str]] = {
    "general": [
        "llama-3.1-8b-instant",                          # simple → 8B
        "meta-llama/llama-4-scout-17b-16e-instruct",     # moderate
        "openai/gpt-oss-20b",
        "qwen/qwen3-32b",
        "llama-3.3-70b-versatile",
    ],
    "coding": [
        "meta-llama/llama-4-scout-17b-16e-instruct",
        "openai/gpt-oss-20b",
        "qwen/qwen3-32b",
        "llama-3.3-70b-versatile",
        "llama-3.1-8b-instant",
    ],
    "reasoning": [
        "openai/gpt-oss-20b",
        "qwen/qwen3-32b",
        "llama-3.3-70b-versatile",
        "meta-llama/llama-4-scout-17b-16e-instruct",
        "llama-3.1-8b-instant",
    ],
    "math": [
        "openai/gpt-oss-20b",
        "qwen/qwen3-32b",
        "llama-3.3-70b-versatile",
        "meta-llama/llama-4-scout-17b-16e-instruct",
        "llama-3.1-8b-instant",
    ],
    "summarization": [
        "llama-3.1-8b-instant",
        "meta-llama/llama-4-scout-17b-16e-instruct",
        "openai/gpt-oss-20b",
        "qwen/qwen3-32b",
        "llama-3.3-70b-versatile",
    ],
    "document": [
        "meta-llama/llama-4-scout-17b-16e-instruct",
        "qwen/qwen3-32b",
        "llama-3.3-70b-versatile",
        "openai/gpt-oss-20b",
        "llama-3.1-8b-instant",
    ],
    "creative": [
        "meta-llama/llama-4-scout-17b-16e-instruct",
        "openai/gpt-oss-20b",
        "llama-3.3-70b-versatile",
        "qwen/qwen3-32b",
        "llama-3.1-8b-instant",
    ],
}

# Policy: preferred model_id per (task, complexity_tier)
# "Smallest model that can still answer well"
_ROUTING_POLICY: dict[str, dict[str, str]] = {
    "general": {
        "simple":   "llama-3.1-8b-instant",
        "moderate": "meta-llama/llama-4-scout-17b-16e-instruct",
        "complex":  "openai/gpt-oss-20b",
    },
    "coding": {
        "simple":   "llama-3.1-8b-instant",
        "moderate": "openai/gpt-oss-20b",
        "complex":  "qwen/qwen3-32b",
    },
    "math": {
        "simple":   "openai/gpt-oss-20b",
        "moderate": "qwen/qwen3-32b",
        "complex":  "llama-3.3-70b-versatile",
    },
    "reasoning": {
        "simple":   "openai/gpt-oss-20b",
        "moderate": "qwen/qwen3-32b",
        "complex":  "llama-3.3-70b-versatile",
    },
    "creative": {
        "simple":   "meta-llama/llama-4-scout-17b-16e-instruct",
        "moderate": "openai/gpt-oss-20b",
        "complex":  "llama-3.3-70b-versatile",
    },
    "document": {
        "simple":   "meta-llama/llama-4-scout-17b-16e-instruct",
        "moderate": "qwen/qwen3-32b",
        "complex":  "llama-3.3-70b-versatile",
    },
    "summarization": {
        "simple":   "llama-3.1-8b-instant",
        "moderate": "meta-llama/llama-4-scout-17b-16e-instruct",
        "complex":  "openai/gpt-oss-20b",
    },
}

# Capability tier number per model (for dashboard display)
_MODEL_TIER: dict[str, int] = {
    "llama-3.1-8b-instant":                      1,
    "meta-llama/llama-4-scout-17b-16e-instruct":  2,
    "openai/gpt-oss-20b":                         3,
    "qwen/qwen3-32b":                             4,
    "llama-3.3-70b-versatile":                    5,
}


def _get_candidate_pool(task_type: str) -> list:
    """Return model objects for the task-specific candidate pool."""
    pool_ids = _TASK_CANDIDATE_POOLS.get(task_type, [])
    if not pool_ids:
        # Fallback: all available models
        return [m for m in MODEL_REGISTRY if m.available]
    return [
        MODEL_BY_ID[mid]
        for mid in pool_ids
        if mid in MODEL_BY_ID and MODEL_BY_ID[mid].available
    ]


def _preferred_model(task_type: str, complexity: float) -> Optional[str]:
    """Return the policy-preferred model_id for this task + complexity."""
    tier = _complexity_tier(complexity)
    return _ROUTING_POLICY.get(task_type, {}).get(tier)


# ── Dynamic weights ───────────────────────────────────────────────────────────
# Weights shift per complexity tier so the right axis dominates:
#   Simple  → cost + latency dominate  → naturally picks 8B
#   Moderate→ task fit dominates       → picks Scout / GPT-OSS
#   Complex → quality + task fit       → picks Qwen / 70B

_WEIGHTS: dict[str, dict[str, float]] = {
    "simple": {
        "task_fit":   0.20,
        "complexity": 0.00,   # not relevant — all small models handle simple well
        "quality":    0.00,
        "cost":       0.35,
        "latency":    0.30,
        "historical": 0.15,
    },
    "moderate": {
        "task_fit":   0.35,
        "complexity": 0.25,
        "quality":    0.00,
        "cost":       0.20,
        "latency":    0.20,
        "historical": 0.00,
    },
    "complex": {
        "task_fit":   0.45,
        "complexity": 0.30,
        "quality":    0.15,
        "cost":       0.05,
        "latency":    0.05,
        "historical": 0.00,
    },
}


# ── Model scoring ──────────────────────────────────────────────────────────────

def _score_model(
    model,
    task_type: str,
    complexity: float,
    history: dict,
    preferred_model_id: Optional[str],
) -> float:
    """
    Compute a utility score [0.0, 1.0] for one model.

    Dimensions (weights shift by complexity tier):
      task_fit   – task_scores[task_type] / 10
      complexity – how well model size matches query difficulty
      quality    – average task_score across all tasks / 10
      cost       – inverted normalized cost
      latency    – inverted normalized latency
      historical – historical success rate from logs (if available)

    A +0.12 additive bonus is applied to the policy-preferred model to
    ensure the routing policy wins except when a clear quality gap exists.
    """
    tier    = _complexity_tier(complexity)
    weights = _WEIGHTS[tier]

    # task_fit
    raw_task  = model.task_scores.get(task_type, model.task_scores.get("general", 5))
    task_dim  = raw_task / 10.0

    # quality (avg across all task scores)
    avg_q     = sum(model.task_scores.values()) / max(len(model.task_scores), 1)
    quality_dim = avg_q / 10.0

    # complexity match (model size vs. query difficulty)
    if tier == "simple":
        # Penalise overkill — ideal is 8B
        complexity_dim = max(0.0, 1.0 - ((model.size_b - 8.0) / 30.0))
    elif tier == "moderate":
        # Sweet spot around 20B
        complexity_dim = max(0.0, 1.0 - abs(model.size_b - 20.0) / 35.0)
    else:
        # Reward large models
        complexity_dim = min(1.0, model.size_b / 100.0)
    complexity_dim = max(0.0, min(1.0, complexity_dim))

    # cost (lower → higher score)
    max_cost   = max(m.cost_per_m_input + m.cost_per_m_output for m in MODEL_REGISTRY)
    model_cost = model.cost_per_m_input + model.cost_per_m_output
    cost_dim   = 1.0 - (model_cost / max_cost) if max_cost else 0.5

    # latency (lower → higher score)
    hist             = history.get(model.model_id, {})
    actual_latency   = hist.get("avg_latency", model.avg_latency_seconds)
    max_latency      = max(m.avg_latency_seconds for m in MODEL_REGISTRY)
    latency_dim      = 1.0 - (actual_latency / max_latency) if max_latency else 0.5

    # historical success rate (0–1 from logs, 0.5 default when no data)
    historical_dim   = hist.get("success_rate", 0.5)

    score = (
        weights["task_fit"]   * task_dim      +
        weights["complexity"] * complexity_dim +
        weights["quality"]    * quality_dim    +
        weights["cost"]       * cost_dim       +
        weights["latency"]    * latency_dim    +
        weights["historical"] * historical_dim
    )

    # Policy preference bonus — ensures the smallest-capable model wins
    # unless another model is substantially better on the weighted sum.
    if preferred_model_id and model.model_id == preferred_model_id:
        score += 0.12

    return round(min(max(score, 0.0), 1.0), 4)


def rank_models(
    task_type: str,
    complexity: float,
    estimated_input_tokens: int,
    candidate_pool: list,
    classifier_confidence: float = 1.0,
) -> list:
    """
    Score and rank the candidate pool. Returns list of dicts sorted best-first.
    Ties broken by: estimated_cost_usd → avg_latency.
    """
    history           = get_routing_history()
    preferred_model_id = _preferred_model(task_type, complexity)
    ranked            = []

    for model in candidate_pool:
        if not model.available:
            continue
        score    = _score_model(model, task_type, complexity, history, preferred_model_id)
        est_cost = estimate_cost_usd(model, estimated_input_tokens)
        hist     = history.get(model.model_id, {})
        ranked.append({
            "model_id":           model.model_id,
            "display_name":       model.display_name,
            "score":              score,
            "estimated_cost_usd": est_cost,
            "avg_latency":        hist.get("avg_latency", model.avg_latency_seconds),
            "task_score":         model.task_scores.get(task_type, model.task_scores.get("general", 5)),
        })

    # Primary sort: score desc. Tie-break: cost asc → latency asc.
    ranked.sort(key=lambda x: (-x["score"], x["estimated_cost_usd"], x["avg_latency"]))
    for i, r in enumerate(ranked):
        r["rank"] = i + 1

    return ranked


# ── Routing explanation (observability) ───────────────────────────────────────

def _build_routing_explanation(
    task_type: str,
    task_display: str,
    complexity: float,
    classifier_confidence: float,
    candidate_pool: list,
    selected_model_id: str,
    selection_reason: str,
    has_document: bool,
    fallback_used: bool,
    fallback_from: Optional[str],
    estimated_input_tokens: int,
) -> str:
    tier          = _complexity_tier(complexity)
    pool_names    = ", ".join(m.display_name for m in candidate_pool)
    selected_name = MODEL_BY_ID[selected_model_id].display_name if selected_model_id in MODEL_BY_ID else selected_model_id
    tok_econ      = (
        "Token Economy applied (document provided)."
        if has_document
        else "Token Economy skipped (no document)."
    )
    if fallback_used:
        fallback_name = MODEL_BY_ID[fallback_from].display_name if fallback_from in MODEL_BY_ID else fallback_from
        return (
            f"Zero-Shot classified query as '{task_display}' ({classifier_confidence:.0%} confidence). "
            f"Complexity: {tier} ({int(complexity*100)}%). "
            f"Candidate pool: [{pool_names}]. "
            f"Primary model {fallback_name} failed — automatic fallback triggered. "
            f"Selected {selected_name}. {tok_econ}"
        )
    return (
        f"Zero-Shot classified query as '{task_display}' ({classifier_confidence:.0%} confidence). "
        f"Complexity: {tier} ({int(complexity*100)}%). "
        f"Candidate pool: [{pool_names}]. "
        f"Estimated input tokens: {estimated_input_tokens}. "
        f"Dynamic {tier}-query weights applied (task_fit/complexity/cost/latency). "
        f"Selected {selected_name} — {selection_reason}. {tok_econ}"
    )


# ── Model call ────────────────────────────────────────────────────────────────

def _call_model(model_id: str, query: str) -> tuple:
    """Call one model. Returns (answer, usage, latency_seconds). Raises on error."""
    start    = time.perf_counter()
    response = client.chat.completions.create(
        model=model_id,
        messages=[{"role": "user", "content": query}],
        timeout=REQUEST_TIMEOUT_SECONDS,
    )
    latency = round(time.perf_counter() - start, 3)
    return response.choices[0].message.content, response.usage, latency


# ── Public routing function ────────────────────────────────────────────────────

def route_query(
    query: str,
    has_document: bool = False,
    source: str = "live_api",
) -> dict:
    """
    Full AMRE routing pipeline.

    Steps
    -----
    1. Zero-shot classify task type
    2. Rule-based complexity estimation
    3. Select task-specific candidate pool
    4. Score & rank pool with dynamic weights
    5. Pick winner (tie-break: cost → latency)
    6. Call model with automatic fallback chain
    7. Return complete decision record with per-step timing
    """
    pipeline_start = time.perf_counter()

    # ── Step 1: Classify ──────────────────────────────────────────────────────
    t0                    = time.perf_counter()
    clf_result            = _get_classifier().classify(query)
    classification_ms     = (time.perf_counter() - t0) * 1000

    task_type             = clf_result["task"]           # internal key
    task_display          = clf_result["task_display"]   # human-readable
    task_confidence       = clf_result["confidence"]
    runner_up             = clf_result["runner_up"]
    runner_up_internal    = clf_result["runner_up_internal"]
    confidence_gap        = clf_result["confidence_gap"]
    multi_intent          = clf_result["multi_intent"]
    top_predictions       = clf_result["top_predictions"]
    classifier_model      = clf_result["model"]

    # ── Step 2: Complexity ────────────────────────────────────────────────────
    t0                    = time.perf_counter()
    complexity, complexity_reasons = estimate_complexity(query, has_document)
    complexity_ms         = (time.perf_counter() - t0) * 1000

    # ── Step 3: Candidate pool ────────────────────────────────────────────────
    t0                    = time.perf_counter()
    candidate_pool        = _get_candidate_pool(task_type)
    pool_ms               = (time.perf_counter() - t0) * 1000

    estimated_input_tokens = _estimate_input_tokens(query)

    # ── Step 4: Rank ──────────────────────────────────────────────────────────
    t0                    = time.perf_counter()
    ranked                = rank_models(
        task_type, complexity, estimated_input_tokens,
        candidate_pool=candidate_pool,
        classifier_confidence=task_confidence,
    )
    ranking_ms            = (time.perf_counter() - t0) * 1000

    if not ranked:
        raise RuntimeError("No available models in registry.")

    # ── Step 5: Select winner ─────────────────────────────────────────────────
    t0                    = time.perf_counter()
    chosen_model_id       = ranked[0]["model_id"]
    selection_notes       = []

    # If top two are within 0.05 apply tie-breakers
    if len(ranked) > 1 and abs(ranked[0]["score"] - ranked[1]["score"]) < 0.05:
        a, b = ranked[0], ranked[1]
        if a["task_score"] != b["task_score"]:
            chosen_model_id = (a if a["task_score"] > b["task_score"] else b)["model_id"]
            selection_notes.append("Higher Task Fit")
        elif a["estimated_cost_usd"] != b["estimated_cost_usd"]:
            chosen_model_id = (a if a["estimated_cost_usd"] < b["estimated_cost_usd"] else b)["model_id"]
            selection_notes.append("Lower Estimated Cost")
        elif a["avg_latency"] != b["avg_latency"]:
            chosen_model_id = (a if a["avg_latency"] < b["avg_latency"] else b)["model_id"]
            selection_notes.append("Lower Average Latency")
        else:
            selection_notes.append("Selected by utility rank (tie)")
    else:
        selection_notes.append("Highest Utility Score")

    selection_reason = "; ".join(selection_notes)

    # Preferred model / capability tier for dashboard observability
    preferred_id     = _preferred_model(task_type, complexity)
    preferred_tier   = _MODEL_TIER.get(preferred_id) if preferred_id else None
    preferred_size   = MODEL_BY_ID[preferred_id].size_b if preferred_id in MODEL_BY_ID else None
    tier_display     = (
        f"Tier {preferred_tier} ({int(preferred_size)}B)"
        if preferred_tier and preferred_size else None
    )
    tier_reason      = (
        f"{task_display} query, {_complexity_tier(complexity)} complexity → preferred {MODEL_BY_ID[preferred_id].display_name}"
        if preferred_id and preferred_id in MODEL_BY_ID else None
    )
    decision_ms      = (time.perf_counter() - t0) * 1000

    # ── Step 6: Call model with fallback ──────────────────────────────────────
    answer        = ""
    usage         = None
    latency       = 0.0
    fallback_used = False
    fallback_from: Optional[str] = None
    fallback_reason: Optional[str] = None

    primary        = chosen_model_id
    attempts       = 0
    tried: set     = set()
    # Fallback chain: chosen first, then rest of ranked pool in score order
    fallback_chain = [chosen_model_id] + [
        r["model_id"] for r in ranked if r["model_id"] != chosen_model_id
    ]

    inference_start = time.perf_counter()
    for model_id in fallback_chain:
        if model_id in tried or attempts > MAX_FALLBACK_ATTEMPTS:
            break
        tried.add(model_id)
        try:
            answer, usage, latency = _call_model(model_id, query)
            if attempts > 0:
                fallback_used   = True
                fallback_from   = primary
                fallback_reason = f"Fell back from {primary} after {attempts} attempt(s)"
            chosen_model_id = model_id
            break
        except Exception as exc:
            attempts += 1
            if attempts == 1:
                fallback_from   = model_id
                fallback_reason = str(exc)[:120]
            if model_id in MODEL_BY_ID:
                MODEL_BY_ID[model_id].available = False
    inference_ms = (time.perf_counter() - inference_start) * 1000

    if not answer:
        raise RuntimeError("All models failed. Check API key and network.")

    # ── Costs ─────────────────────────────────────────────────────────────────
    chosen_profile = MODEL_BY_ID[chosen_model_id]
    input_tokens   = usage.prompt_tokens     if usage else estimated_input_tokens
    output_tokens  = usage.completion_tokens if usage else 300
    actual_cost    = calculate_cost_usd(chosen_profile, input_tokens, output_tokens)
    est_cost       = ranked[0]["estimated_cost_usd"]

    routing_explanation = _build_routing_explanation(
        task_type=task_type,
        task_display=task_display,
        complexity=complexity,
        classifier_confidence=task_confidence,
        candidate_pool=candidate_pool,
        selected_model_id=chosen_model_id,
        selection_reason=selection_reason,
        has_document=has_document,
        fallback_used=fallback_used,
        fallback_from=fallback_from,
        estimated_input_tokens=estimated_input_tokens,
    )

    total_ms = (time.perf_counter() - pipeline_start) * 1000

    return {
        # ── Query context
        "timestamp":              None,
        "source":                 source,
        "query":                  query,
        # ── Classification
        "task_type":              task_type,
        "task_confidence":        task_confidence,
        "complexity_score":       complexity,
        "complexity_reasons":     complexity_reasons,
        "complexity_description": _complexity_description(complexity),
        # ── Decision
        "model_id":               chosen_model_id,
        "model_display_name":     chosen_profile.display_name,
        "routing_score":          next(
            (r["score"] for r in ranked if r["model_id"] == chosen_model_id), 0.0
        ),
        "all_model_scores":       ranked,
        "selection_reason":       selection_reason,
        "routing_explanation":    routing_explanation,
        # ── Capability tier (dashboard)
        "capability_tier":        preferred_tier,
        "capability_tier_display":tier_display,
        "capability_tier_reason": tier_reason,
        # ── Costs & tokens
        "estimated_cost_usd":     est_cost,
        "actual_cost_usd":        actual_cost,
        "cost_saved":             round(est_cost - actual_cost, 6),
        "input_tokens":           input_tokens,
        "output_tokens":          output_tokens,
        "total_tokens":           input_tokens + output_tokens,
        # ── Latency
        "latency_seconds":        latency,
        # ── Fallback
        "fallback_used":          fallback_used,
        "fallback_from":          fallback_from,
        "fallback_reason":        fallback_reason,
        # ── Classifier detail (dashboard + logging)
        "classifier": {
            "model":               classifier_model,
            "task_display":        task_display,
            "task_internal":       task_type,
            "confidence":          task_confidence,
            "runner_up":           runner_up,
            "runner_up_internal":  runner_up_internal,
            "confidence_gap":      confidence_gap,
            "multi_intent":        multi_intent,
            "top_predictions":     top_predictions,
        },
        # ── Per-step timing (ms)
        "execution_timing": {
            "classification_ms":  round(classification_ms, 2),
            "complexity_ms":      round(complexity_ms, 2),
            "pool_selection_ms":  round(pool_ms, 2),
            "ranking_ms":         round(ranking_ms, 2),
            "decision_ms":        round(decision_ms, 2),
            "inference_ms":       round(inference_ms, 2),
            "total_pipeline_ms":  round(total_ms, 2),
        },
        # ── Answer
        "answer_preview":         answer[:300] if answer else "",
        "answer":                 answer,
    }