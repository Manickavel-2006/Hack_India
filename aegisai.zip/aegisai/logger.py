"""
AegisAI - Unified Logger
Centralised logging for all pipeline stages.
Tracks: routing decisions, cost (estimated + actual), latency,
        token usage, fallback events, and routing history.
"""

import os
import json
from datetime import datetime, timezone
from typing import Optional

LOG_DIR = "logs"
ROUTING_LOG    = os.path.join(LOG_DIR, "routing_log.json")
HISTORY_LOG    = os.path.join(LOG_DIR, "routing_history.json")


# ── Internal helpers ──────────────────────────────────────────────────────────
def _read(path: str) -> list:
    os.makedirs(LOG_DIR, exist_ok=True)
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf-8") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return []


def _write(path: str, data: list) -> None:
    os.makedirs(LOG_DIR, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def _append(path: str, record: dict) -> None:
    data = _read(path)
    data.append(record)
    _write(path, data)


# ── Cost calculation ───────────────────────────────────────────────────────────
def calculate_cost_usd(
    model_profile,
    input_tokens: int,
    output_tokens: int,
) -> float:
    """Estimate actual cost in USD based on token counts and model pricing."""
    cost = (
        (input_tokens  / 1_000_000) * model_profile.cost_per_m_input +
        (output_tokens / 1_000_000) * model_profile.cost_per_m_output
    )
    return round(cost, 8)


def estimate_cost_usd(
    model_profile,
    estimated_input_tokens: int,
    estimated_output_tokens: int = 300,
) -> float:
    """Pre-flight cost estimate before making the API call."""
    return calculate_cost_usd(model_profile, estimated_input_tokens, estimated_output_tokens)


# ── Main log entry ─────────────────────────────────────────────────────────────
def log_routing_decision(
    query: str,
    original_query: Optional[str],
    task_type: str,
    task_confidence: float,
    complexity_score: float,
    complexity_reasons: list,
    model_id: str,
    model_display_name: str,
    routing_score: float,
    all_model_scores: list,          # [{model_id, score, rank}, ...]
    estimated_cost_usd: float,
    actual_cost_usd: float,
    input_tokens: int,
    output_tokens: int,
    latency_seconds: float,
    answer: str,
    token_prediction: Optional[dict] = None,
    token_economy: Optional[dict] = None,
    compression_ratio: Optional[float] = None,
    fallback_used: bool = False,
    fallback_from: Optional[str] = None,
    fallback_reason: Optional[str] = None,
    source: str = "live_api",
) -> dict:
    """
    Write a complete routing decision record to the routing log.
    Returns the record dict (used by the API response).
    """
    record = {
        "timestamp":            datetime.now(timezone.utc).isoformat(),
        "source":               source,
        "query":                query,
        "original_query":       original_query,
        # Classification
        "task_type":            task_type,
        "task_confidence":      task_confidence,
        # Complexity
        "complexity_score":     complexity_score,
        "complexity_reasons":   complexity_reasons,
        # Routing decision
        "model_id":             model_id,
        "model_display_name":   model_display_name,
        "routing_score":        routing_score,
        "all_model_scores":     all_model_scores,
        # Cost
        "estimated_cost_usd":   estimated_cost_usd,
        "actual_cost_usd":      actual_cost_usd,
        # Performance
        "input_tokens":         input_tokens,
        "output_tokens":        output_tokens,
        "total_tokens":         input_tokens + output_tokens,
        "latency_seconds":      latency_seconds,
        # Fallback
        "fallback_used":        fallback_used,
        "fallback_from":        fallback_from,
        "fallback_reason":      fallback_reason,
        # Token Economy (populated when a document is attached)
        "token_prediction":     token_prediction,
        "compression_ratio":    compression_ratio,
        "token_economy":        token_economy,
        # Answer (truncated in log to save space)
        "answer_preview":       answer[:300] if answer else "",
        "answer":               answer,
    }

    _append(ROUTING_LOG, record)
    _update_history(model_id, latency_seconds, actual_cost_usd, routing_score)
    return record


# ── Routing history (used to improve future decisions) ─────────────────────────
def _update_history(
    model_id: str,
    latency_seconds: float,
    cost_usd: float,
    routing_score: float,
) -> None:
    """
    Maintain a running average of latency and cost per model.
    AMRE reads this to calibrate future routing decisions.
    """
    history = _read(HISTORY_LOG)
    entry = next((h for h in history if h["model_id"] == model_id), None)

    if entry is None:
        history.append({
            "model_id":        model_id,
            "call_count":      1,
            "avg_latency":     latency_seconds,
            "avg_cost_usd":    cost_usd,
            "avg_score":       routing_score,
            "total_cost_usd":  cost_usd,
            "last_used":       datetime.now(timezone.utc).isoformat(),
        })
    else:
        n = entry["call_count"]
        entry["avg_latency"]  = round((entry["avg_latency"] * n + latency_seconds) / (n + 1), 4)
        entry["avg_cost_usd"] = round((entry["avg_cost_usd"] * n + cost_usd) / (n + 1), 8)
        entry["avg_score"]    = round((entry["avg_score"] * n + routing_score) / (n + 1), 4)
        entry["total_cost_usd"] = round(entry["total_cost_usd"] + cost_usd, 8)
        entry["call_count"]   = n + 1
        entry["last_used"]    = datetime.now(timezone.utc).isoformat()

    _write(HISTORY_LOG, history)


def get_routing_history() -> dict:
    """Return routing history keyed by model_id (for AMRE to read)."""
    return {h["model_id"]: h for h in _read(HISTORY_LOG)}


def get_all_routing_logs() -> list:
    return _read(ROUTING_LOG)